let totalFishing = 0;
let userBalance = 0;
const resultDisplay = document.getElementById("result");
const statsDisplay = document.getElementById("stats");

const fishTypes = [
  { name: "고래", reward: 100, chance: 0.05 },
  { name: "상어", reward: 50, chance: 0.15 },
  { name: "다랑어", reward: 10, chance: 0.3 },
  { name: "문어", reward: 0, chance: 0.2 },
  { name: "랍스터", reward: 0, chance: 0.1 },
  { name: "새우", reward: 0, chance: 0.1 },
  { name: "조개", reward: 0, chance: 0.1 }
];

function startFishing() {
  totalFishing++;
  let rand = Math.random();
  let cumulative = 0;
  for (let fish of fishTypes) {
    cumulative += fish.chance;
    if (rand < cumulative) {
      userBalance += fish.reward;
      resultDisplay.textContent = `${fish.name}를(을) 낚았습니다! (+${fish.reward} WLD)`;
      break;
    }
  }
  if (totalFishing % 500 === 0) {
    userBalance += 100;
    resultDisplay.textContent += " 🎉 고래 보너스 지급! (+100 WLD)";
  } else if (totalFishing % 300 === 0) {
    userBalance += 50;
    resultDisplay.textContent += " 🎁 상어 보너스 지급! (+50 WLD)";
  } else if (totalFishing % 100 === 0) {
    userBalance += 10;
    resultDisplay.textContent += " 🎊 다랑어 보너스 지급! (+10 WLD)";
  }
  statsDisplay.textContent = `총 낚시 횟수: ${totalFishing} | 보유 WLD: ${userBalance}`;
}
